var e={},t=(_,n,o)=>(e.__RSC_SERVER_MANIFEST=_.__RSC_SERVER_MANIFEST=`{
  "node": {},
  "edge": {},
  "encryptionKey": "sGxtjW1SoT071wRElfW3qDRb34U8QjUmeWfuuGTf30I="
}`,e);export{t as __getNamedExports};
