import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import {
  CALCULATOR_ROUTES,
  SLUG_TO_CONFIG,
  getCalculatorSlugs,
} from '@/lib/calculator-routes';
import {
  HOME_FAQS,
  ILLINOIS_FAQS,
  TEXAS_FAQS,
  FLORIDA_FAQS,
  CALIFORNIA_FAQS,
  NEWYORK_FAQS,
  MORTGAGE_FAQS,
  CAPITAL_GAINS_FAQS,
  SELF_EMPLOYMENT_FAQS,
  RETIREMENT_FAQS,
  RELOCATION_FAQS,
  TAX_REFUND_FAQS,
  SALES_TAX_FAQS,
  OVERTIME_FAQS,
  GEORGIA_FAQS,
  LOTTERY_TAX_FAQS,
  IRS_WITHHOLDING_FAQS,
  PROPERTY_TAX_FAQS,
  BONUS_TAX_FAQS,
  VIRGINIA_FAQS,
  FAQItem,
} from '@/lib/faq-data';
import { CalculatorClientPage } from './calculator-client-page';
import { getAllPosts } from '@/lib/blog-db';
import { SITE_URL } from '@/lib/site-config';
import { ShareButtons } from '@/components/finance/share-buttons';
import { LinkToUs } from '@/components/finance/link-to-us';

export function generateStaticParams() {
  return getCalculatorSlugs().map((slug) => ({ calculator: slug }));
}

// ─── Per-Page Metadata ────────────────────────────────────────────────────────

export async function generateMetadata({
  params,
}: {
  params: Promise<{ calculator: string }>;
}): Promise<Metadata> {
  const { calculator } = await params;
  const config = SLUG_TO_CONFIG[calculator];

  if (!config) {
    return { title: 'Calculator Not Found' };
  }

  const baseUrl = SITE_URL;

  return {
    title: config.metaTitle,
    description: config.metaDesc,
    keywords: config.keywords,
    authors: [{ name: 'TheTaxCalc' }],
    alternates: {
      canonical: `${baseUrl}${config.canonicalPath}`,
    },
    openGraph: {
      title: config.ogTitle,
      description: config.ogDescription,
      url: `${baseUrl}${config.canonicalPath}`,
      siteName: 'TheTaxCalc',
      type: 'website',
      locale: 'en_US',
      images: [
        {
          url: `${baseUrl}/opengraph-image.png`,
          width: 1200,
          height: 630,
          alt: config.ogTitle,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title: config.ogTitle,
      description: config.ogDescription,
      images: [`${baseUrl}/opengraph-image.png`],
    },
  };
}

// ─── JSON-LD FAQ Helper ─────────────────────────────────────────────────────────

function faqsToJsonLd(faqs: { question: string; answer: string }[]) {
  return {
    '@type': 'FAQPage' as const,
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  };
}

// ─── JSON-LD Schema Generators ───────────────────────────────────────────────

function getHomeJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'WebPage',
        name: 'Paycheck Calculator — Federal, FICA & State Tax Take-Home Pay',
        description:
          'Free 2026 paycheck calculator. Instantly compute your take-home pay after federal tax, FICA (Social Security + Medicare), and state income tax deductions.',
        url: `${SITE_URL}/paycheck-calculator`,
        inLanguage: 'en-US',
        dateModified: '2026-01-01',
        breadcrumb: {
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
            { '@type': 'ListItem', position: 2, name: 'Paycheck Calculator', item: `${SITE_URL}/paycheck-calculator` },
          ],
        },
      },
      {
        '@type': 'SoftwareApplication',
        name: 'TheTaxCalc Paycheck Calculator',
        applicationCategory: 'FinanceApplication',
        operatingSystem: 'Web',
        offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
      },
      {
        '@type': 'HowTo',
        name: 'How to Calculate Your Take-Home Pay',
        step: [
          { '@type': 'HowToStep', name: 'Enter Gross Salary', text: 'Input your annual, monthly, bi-weekly, weekly, or hourly salary' },
          { '@type': 'HowToStep', name: 'Select State', text: 'Choose IL (4.95%), TX (0%), FL (0%), CA (1%–13.3%), or NY (4%–10.9%)' },
          { '@type': 'HowToStep', name: 'Choose Filing Status', text: 'Select Single, Married, or Head of Household' },
          { '@type': 'HowToStep', name: 'Add Pre-Tax Deductions', text: 'Enter 401(k) and HSA contributions' },
          { '@type': 'HowToStep', name: 'View Instant Results', text: 'See your net take-home pay, effective tax rate, and full deduction breakdown' },
        ],
      },
      faqsToJsonLd(HOME_FAQS),
    ],
  };
}

function getIllinoisJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Illinois Paycheck Calculator', item: `${SITE_URL}/illinois-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Illinois Paycheck Calculator 2026', url: `${SITE_URL}/illinois-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Illinois Paycheck Math Solver', description: 'Computes net take-home pay: Net = Gross - Federal Tax - FICA - IL State Tax, where IL Tax = (Gross - Personal Exemption) × 4.95%', mathExpression: 'Net = G - Fed(G - StdDed) - FICA(G) - (G - Exempt) × 0.0495' },
      { '@type': 'Dataset', name: '2026 Illinois Tax Rates', variableMeasured: [
        { name: 'Illinois Flat Tax Rate', value: '4.95%' },
        { name: 'Illinois Personal Exemption', value: '$2,775' },
        { name: 'Federal Standard Deduction (Single)', value: '$15,000' },
        { name: 'Social Security Wage Cap', value: '$176,100' },
      ]},
      faqsToJsonLd(ILLINOIS_FAQS),
    ],
  };
}

function getTexasJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Texas Paycheck Calculator', item: `${SITE_URL}/texas-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Texas Paycheck Calculator 2026', url: `${SITE_URL}/texas-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Texas Paycheck Math Solver', description: 'Computes net take-home pay in Texas: Net = Gross - Federal Tax - FICA. Texas has 0% state income tax.', mathExpression: 'Net = G - Fed(G - StdDed) - FICA(G)' },
      { '@type': 'Dataset', name: '2026 Texas Tax & Cost of Living Data', variableMeasured: [
        { name: 'Texas State Income Tax Rate', value: '0%' },
        { name: 'Texas Average Effective Property Tax Rate', value: '1.71%' },
        { name: 'Texas Average Combined Sales Tax Rate', value: '8.2%' },
      ]},
      faqsToJsonLd(TEXAS_FAQS),
    ],
  };
}

function getFloridaJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Florida Paycheck Calculator', item: `${SITE_URL}/florida-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Florida Paycheck Calculator 2026', url: `${SITE_URL}/florida-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'Dataset', name: '2026 Florida Tax & Cost of Living Data', variableMeasured: [
        { name: 'Florida State Income Tax Rate', value: '0%' },
        { name: 'Florida Average Effective Property Tax Rate', value: '0.86%' },
        { name: 'Florida Average Combined Sales Tax Rate', value: '7.0%' },
      ]},
      faqsToJsonLd(FLORIDA_FAQS),
    ],
  };
}

function getCaliforniaJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'California Paycheck Calculator', item: `${SITE_URL}/california-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'California Paycheck Calculator 2026', url: `${SITE_URL}/california-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'California Paycheck Math Solver', description: 'Computes net take-home pay with CA progressive tax brackets 1%-13.3%.', mathExpression: 'Net = G - Fed(G - StdDed) - FICA(G) - CA_Progressive(G - StdDed_CA)' },
      { '@type': 'Dataset', name: '2026 California Tax Rates', variableMeasured: [
        { name: 'California Top Marginal Tax Rate', value: '13.3%' },
        { name: 'California Standard Deduction (Single)', value: '$6,083' },
        { name: 'California Average Combined Sales Tax', value: '8.82%' },
      ]},
      faqsToJsonLd(CALIFORNIA_FAQS),
    ],
  };
}

function getNewYorkJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'New York Paycheck Calculator', item: `${SITE_URL}/new-york-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'New York Paycheck Calculator 2026', url: `${SITE_URL}/new-york-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'New York Paycheck Math Solver', description: 'Computes net take-home pay with NY progressive tax brackets 4%-10.9% plus potential NYC tax.', mathExpression: 'Net = G - Fed(G - StdDed) - FICA(G) - NY_Progressive(G - StdDed_NY) - NYC_Tax' },
      { '@type': 'Dataset', name: '2026 New York Tax Rates', variableMeasured: [
        { name: 'New York Top Marginal Tax Rate', value: '10.9%' },
        { name: 'New York Standard Deduction (Single)', value: '$8,100' },
        { name: 'NYC Income Tax Rate Range', value: '3.078% - 3.876%' },
      ]},
      faqsToJsonLd(NEWYORK_FAQS),
    ],
  };
}

function getMortgageJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Mortgage Calculator', item: `${SITE_URL}/mortgage-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Mortgage Calculator with Extra Payments', url: `${SITE_URL}/mortgage-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Mortgage Amortization Solver', description: 'Computes monthly payment using M = P × [r(1+r)^n] / [(1+r)^n - 1]', mathExpression: 'M = P × [r(1+r)^n] / [(1+r)^n - 1]' },
      faqsToJsonLd(MORTGAGE_FAQS),
    ],
  };
}

function getRetirementJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: '401(k) Retirement Projection', item: `${SITE_URL}/401k-retirement-calculator` },
      ]},
      { '@type': 'WebApplication', name: '401(k) Retirement Projection Calculator 2026', url: `${SITE_URL}/401k-retirement-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: '401(k) Compound Growth Solver', description: 'Computes projected 401(k) balance using annual contributions + employer match with compound annual growth.', mathExpression: 'B(n) = Σ C_annual × (1 + r)^(n-i)' },
      faqsToJsonLd(RETIREMENT_FAQS),
    ],
  };
}

function getRelocationJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Salary Relocation Calculator', item: `${SITE_URL}/relocation-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Salary Relocation Calculator 2026', url: `${SITE_URL}/relocation-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      faqsToJsonLd(RELOCATION_FAQS),
    ],
  };
}

function getCapitalGainsJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Capital Gains Tax Calculator', item: `${SITE_URL}/capital-gains-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Capital Gains Tax Calculator 2026', url: `${SITE_URL}/capital-gains-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      faqsToJsonLd(CAPITAL_GAINS_FAQS),
    ],
  };
}

function getSelfEmploymentJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Self-Employment Tax Calculator', item: `${SITE_URL}/self-employment-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Self-Employment Tax Calculator 2026', url: `${SITE_URL}/self-employment-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      faqsToJsonLd(SELF_EMPLOYMENT_FAQS),
    ],
  };
}

function getTaxRefundJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Tax Refund Calculator', item: `${SITE_URL}/tax-refund-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Tax Refund Calculator 2026', url: `${SITE_URL}/tax-refund-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Tax Refund Math Solver', description: 'Computes estimated tax refund: Refund = Total Taxes Withheld - (Federal Tax Owed + State Tax Owed), where Federal Tax Owed uses progressive brackets with standard/itemized deductions and tax credits.', mathExpression: 'Refund = (Fed_Withheld + State_Withheld) - (Fed_Tax(Gross - Deduction) - Credits + State_Tax)' },
      { '@type': 'Dataset', name: '2026 Tax Refund Key Rates', variableMeasured: [
        { name: 'Standard Deduction (Single)', value: '$15,000' },
        { name: 'Standard Deduction (Married)', value: '$30,000' },
        { name: 'Child Tax Credit', value: '$2,000 per child' },
        { name: 'Refundable CTC Portion', value: 'Up to $1,700' },
        { name: 'EIC Maximum (3+ children)', value: '$7,430' },
      ]},
      faqsToJsonLd(TAX_REFUND_FAQS),
    ],
  };
}

function getSalesTaxJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Sales Tax Calculator', item: `${SITE_URL}/sales-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Sales Tax Calculator 2026', url: `${SITE_URL}/sales-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Sales Tax Math Solver', description: 'Computes sales tax amount and total price: Tax = Price × Rate, Total = Price + Tax. Reverse: Original = Total ÷ (1 + Rate).', mathExpression: 'Tax = P × R; Total = P × (1 + R); Reverse: P = Total ÷ (1 + R)' },
      { '@type': 'Dataset', name: '2026 US Sales Tax Rates', variableMeasured: [
        { name: 'Average US Combined Rate', value: '~6.6%' },
        { name: 'Highest Combined Rate', value: '9.56% (Louisiana/Tennessee)' },
        { name: 'No Sales Tax States', value: 'DE, MT, NH, OR' },
        { name: 'California Combined Rate', value: '8.82%' },
        { name: 'Texas Combined Rate', value: '8.20%' },
      ]},
      faqsToJsonLd(SALES_TAX_FAQS),
    ],
  };
}

function getOvertimeJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Overtime Tax Calculator', item: `${SITE_URL}/overtime-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Overtime Tax Calculator 2026', url: `${SITE_URL}/overtime-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Overtime Tax Math Solver', description: 'Computes after-tax overtime pay: OT Pay = Hours × Rate × 1.5, After-Tax = OT Pay × (1 - Marginal Rate - FICA - State Rate).', mathExpression: 'After-Tax OT = H × R × 1.5 × (1 - Fed_Marginal - FICA - State)' },
      { '@type': 'Dataset', name: '2026 Overtime Tax Data', variableMeasured: [
        { name: 'Federal Overtime Rate', value: '1.5x (time and a half)' },
        { name: 'Federal Tax on OT', value: 'Taxed at marginal rate' },
        { name: 'FICA Rate', value: '7.65%' },
        { name: 'Effective OT Tax Rate', value: 'Typically 25%–35%' },
      ]},
      faqsToJsonLd(OVERTIME_FAQS),
    ],
  };
}

function getGeorgiaJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Georgia Tax Calculator', item: `${SITE_URL}/georgia-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Georgia Tax Calculator 2026', url: `${SITE_URL}/georgia-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Georgia Paycheck Math Solver', description: 'Computes net take-home pay: Net = Gross - Federal Tax - FICA - GA State Tax, where GA Tax = (Gross - StdDed) × 5.49%.', mathExpression: 'Net = G - Fed(G - StdDed) - FICA(G) - (G - StdDed_GA) × 0.0549' },
      { '@type': 'Dataset', name: '2026 Georgia Tax Rates', variableMeasured: [
        { name: 'Georgia Flat Tax Rate', value: '5.49%' },
        { name: 'Georgia Standard Deduction (Single)', value: '$5,400' },
        { name: 'Georgia Standard Deduction (Married)', value: '$7,100' },
        { name: 'Federal Standard Deduction (Single)', value: '$15,000' },
      ]},
      faqsToJsonLd(GEORGIA_FAQS),
    ],
  };
}

function getLotteryJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Lottery Tax Calculator', item: `${SITE_URL}/lottery-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Lottery Tax Calculator 2026', url: `${SITE_URL}/lottery-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Lottery Tax Math Solver', description: 'Computes after-tax lottery winnings: After-Tax = Winnings × (1 - Federal Rate - State Rate), where federal withholding is 24%.', mathExpression: 'After-Tax = W × (1 - 0.24 - StateRate)' },
      { '@type': 'Dataset', name: '2026 Lottery Tax Rates', variableMeasured: [
        { name: 'Federal Withholding Rate', value: '24%' },
        { name: 'Top Federal Marginal Rate', value: '37%' },
        { name: 'States with No Lottery Tax', value: 'CA, DE, FL, NH, PA, SD, TN, TX, WA, WY' },
        { name: 'Average State Lottery Tax', value: '~4%–8%' },
      ]},
      faqsToJsonLd(LOTTERY_TAX_FAQS),
    ],
  };
}

function getIrsWithholdingJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'IRS Withholding Calculator', item: `${SITE_URL}/irs-withholding-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'IRS Withholding Calculator 2026', url: `${SITE_URL}/irs-withholding-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'IRS Withholding Math Solver', description: 'Computes optimal W-4 withholding: Withholding = (Annual Tax Owed - Credits) / Pay Periods, compared to current withholding.', mathExpression: 'Withholding_Period = (Tax_Owed - Credits) / N_Periods' },
      { '@type': 'Dataset', name: '2026 IRS Withholding Data', variableMeasured: [
        { name: 'Standard Deduction (Single)', value: '$15,000' },
        { name: 'Standard Deduction (Married)', value: '$30,000' },
        { name: 'Child Tax Credit', value: '$2,000 per child' },
        { name: 'Underpayment Penalty Threshold', value: '90% of tax owed or 100% of prior year' },
      ]},
      faqsToJsonLd(IRS_WITHHOLDING_FAQS),
    ],
  };
}

function getPropertyTaxJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Property Tax Calculator', item: `${SITE_URL}/property-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Property Tax Calculator 2026', url: `${SITE_URL}/property-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Property Tax Math Solver', description: 'Computes annual property tax: Tax = Assessed Value × Effective Rate. Some states apply assessment ratios.', mathExpression: 'Tax = Assessed_Value × Effective_Rate' },
      { '@type': 'Dataset', name: '2026 US Property Tax Rates', variableMeasured: [
        { name: 'US Average Effective Rate', value: '~1.1%' },
        { name: 'Highest Rate (NJ)', value: '~2.49%' },
        { name: 'Lowest Rate (HI)', value: '~0.29%' },
        { name: 'TX Average Rate', value: '~1.71%' },
        { name: 'FL Average Rate', value: '~0.86%' },
      ]},
      faqsToJsonLd(PROPERTY_TAX_FAQS),
    ],
  };
}

function getBonusTaxJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Bonus Tax Calculator', item: `${SITE_URL}/bonus-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Bonus Tax Calculator 2026', url: `${SITE_URL}/bonus-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Bonus Tax Math Solver', description: 'Computes after-tax bonus using flat 22% method or aggregate method: Flat = Bonus × (1 - 0.22 - FICA - State), Aggregate blends bonus with regular wages.', mathExpression: 'Flat: After-Tax = B × (1 - 0.22 - FICA - State); Aggregate: Tax = Progressive(Income + Bonus)' },
      { '@type': 'Dataset', name: '2026 Bonus Tax Rates', variableMeasured: [
        { name: 'Federal Flat Withholding Rate', value: '22%' },
        { name: 'FICA Rate', value: '7.65%' },
        { name: 'Bonus Under $1M Federal Rate', value: '22% flat' },
        { name: 'Bonus Over $1M Federal Rate', value: '37% flat' },
      ]},
      faqsToJsonLd(BONUS_TAX_FAQS),
    ],
  };
}

function getVirginiaJsonLd() {
  return {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
        { '@type': 'ListItem', position: 2, name: 'Virginia Tax Calculator', item: `${SITE_URL}/virginia-tax-calculator` },
      ]},
      { '@type': 'WebApplication', name: 'Virginia Tax Calculator 2026', url: `${SITE_URL}/virginia-tax-calculator`, applicationCategory: 'FinanceApplication', operatingSystem: 'Web', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@type': 'MathSolver', name: 'Virginia Paycheck Math Solver', description: 'Computes net take-home pay: Net = Gross - Federal Tax - FICA - VA State Tax, where VA Tax uses progressive brackets 2%-5.75%.', mathExpression: 'Net = G - Fed(G - StdDed) - FICA(G) - VA_Progressive(G - StdDed_VA)' },
      { '@type': 'Dataset', name: '2026 Virginia Tax Rates', variableMeasured: [
        { name: 'Virginia Top Marginal Rate', value: '5.75%' },
        { name: 'Virginia Standard Deduction (Single)', value: '$8,000' },
        { name: 'Virginia Standard Deduction (Married)', value: '$16,000' },
        { name: 'VA Tax Brackets', value: '2% – 5.75% (4 brackets)' },
      ]},
      faqsToJsonLd(VIRGINIA_FAQS),
    ],
  };
}

function getJsonLdForType(type: string) {
  switch (type) {
    case 'illinois': return getIllinoisJsonLd();
    case 'texas': return getTexasJsonLd();
    case 'florida': return getFloridaJsonLd();
    case 'california': return getCaliforniaJsonLd();
    case 'newyork': return getNewYorkJsonLd();
    case 'mortgage': return getMortgageJsonLd();
    case 'retirement': return getRetirementJsonLd();
    case 'relocation': return getRelocationJsonLd();
    case 'capital-gains': return getCapitalGainsJsonLd();
    case 'self-employment': return getSelfEmploymentJsonLd();
    case 'tax-refund': return getTaxRefundJsonLd();
    case 'sales-tax': return getSalesTaxJsonLd();
    case 'overtime': return getOvertimeJsonLd();
    case 'georgia': return getGeorgiaJsonLd();
    case 'lottery': return getLotteryJsonLd();
    case 'irs-withholding': return getIrsWithholdingJsonLd();
    case 'property-tax': return getPropertyTaxJsonLd();
    case 'bonus-tax': return getBonusTaxJsonLd();
    case 'virginia': return getVirginiaJsonLd();
    default: return getHomeJsonLd();
  }
}

// ─── Calculator Content Data (Server-Rendered for SEO) ─────────────────────────

interface CalculatorContent {
  howItWorks: string[];
  keyRates: { label: string; value: string }[];
  faqs: FAQItem[];
  relatedCalculators: { slug: string; label: string }[];
}

function getCalculatorContent(type: string): CalculatorContent {
  switch (type) {
    case 'home':
      return {
        howItWorks: [
          'Look at your pay stub sometime. That number at the bottom — the one that actually hits your bank — is way smaller than the number at the top. This calculator tells you why, line by line. All withholding calculations follow <a href="https://www.irs.gov/publications/p15t" target="_blank" rel="noopener noreferrer nofollow">IRS Publication 15-T</a>.',
          'Here\'s what comes out of every paycheck. Federal tax uses progressive brackets from 10% up to 37%, with standard deductions of $15,000 (single) or $30,000 (married). Then <a href="/glossary">FICA</a>: 6.2% for Social Security on income up to $176,100, and 1.45% for Medicare on everything. Make over $200,000? Add another 0.9% Medicare surtax on the amount above that.',
          'My buddy in Chicago and I compared stubs once. Same salary, same filing status. He walked away with about $3,800 less for the year because Illinois takes 4.95% and my state takes nothing. That\'s when it hit me — state tax is not a small factor. We cover five states here: Illinois at 4.95% flat, Texas at 0%, Florida at 0%, California at 1%–13.3% progressive, and New York at 4%–10.9% plus a potential NYC tax.',
          'A couple things that help soften the blow:\n- <a href="/401k-retirement-calculator">401(k) contributions</a> reduce taxable income at both federal and state level\n- HSA contributions do the same\n- These pre-tax deductions are basically a discount on your tax bill',
          'Bottom line — you\'ll see your net pay, effective tax rate, and marginal rate. Most people think their effective rate is higher than it actually is. Go ahead, see for yourself.',
        ],
        keyRates: [
          { label: 'Federal Tax Brackets', value: '10% – 37%' },
          { label: 'Standard Deduction (Single)', value: '$15,000' },
          { label: 'Social Security Rate', value: '6.2% (up to $176,100)' },
          { label: 'Medicare Rate', value: '1.45% (no cap)' },
          { label: 'Additional Medicare Tax', value: '0.9% (above $200K)' },
        ],
        faqs: HOME_FAQS,
        relatedCalculators: [
          { slug: 'illinois-tax-calculator', label: 'Illinois Calculator' },
          { slug: 'texas-tax-calculator', label: 'Texas Calculator' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'new-york-tax-calculator', label: 'New York Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: '401k-retirement-calculator', label: '401(k) Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'illinois':
      return {
        howItWorks: [
          '<a href="https://revenue.illinois.gov/" target="_blank" rel="noopener noreferrer nofollow">4.95%</a>. That\'s it. One flat rate for every Illinois resident, whether you pull in $30K or $300K. No brackets to figure out, no guessing which rate applies. Honestly, it\'s kinda nice not having to navigate a bracket system — even if 4.95% isn\'t exactly cheap compared to the zero-tax states. You get a $2,775 personal exemption for 2026 that comes off the top, so on a $75,000 salary you\'re taxed on $72,225, which comes out to $3,575.14 in state tax. The math is easy to check. My cousin moved from Chicago to Austin last year and he said the <a href="/relocation-calculator">state tax savings alone covered his moving costs</a> within about 8 months.',
          'On top of Illinois tax you\'ve got the federal progressive brackets with the standard deduction, plus FICA at 7.65% combined. <a href="/401k-retirement-calculator">401(k) contributions</a> are your friend here — they reduce taxable income at both the federal and state level, so every dollar you put in saves you money twice.',
          'One thing people don\'t expect: Illinois has no state standard deduction, just that personal exemption. But there\'s a real silver lining if you\'re anywhere near retirement. Illinois doesn\'t touch Social Security benefits, 401(k) distributions, IRA withdrawals, or pension income. The property taxes are brutal — no argument there — but for retirees specifically, the income tax picture is honestly pretty decent.',
        ],
        keyRates: [
          { label: 'Illinois Flat Tax Rate', value: '4.95%' },
          { label: 'IL Personal Exemption', value: '$2,775' },
          { label: 'IL Avg Property Tax Rate', value: '~1.78%' },
          { label: 'IL Avg Combined Sales Tax', value: '8.86%' },
          { label: 'Social Security Wage Cap', value: '$176,100' },
        ],
        faqs: ILLINOIS_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'General Paycheck Calculator' },
          { slug: 'texas-tax-calculator', label: 'Texas Calculator (0% tax)' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator (0% tax)' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'new-york-tax-calculator', label: 'New York Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'texas':
      return {
        howItWorks: [
          'Zero. That\'s the Texas income tax rate. Not "close to zero" or "effectively zero." Actually zero. The Texas Constitution bans a state income tax, so this isn\'t changing.',
          'Your only deductions are federal tax and FICA. Federal uses the 2026 progressive brackets (10%–37%) with standard deductions, plus 6.2% Social Security up to $176,100 and 1.45% Medicare on everything. No state line item on your pay stub. Period.',
          'I talk to people who moved from <a href="/california-tax-calculator">California</a> or <a href="/new-york-tax-calculator">New York</a> and they can\'t get over how much more shows up in their bank account on the same salary. A $100K earner in Texas takes home roughly $79,000. Same salary in California? More like $71,000. That\'s an $8,000 difference from state tax alone.',
          'But Texas gets you elsewhere. <a href="https://comptroller.texas.gov/" target="_blank" rel="noopener noreferrer nofollow">Property taxes</a> average about 1.71% of home value — on a $300,000 house that\'s roughly $5,130 a year. That\'s among the highest in the country. Sales tax runs around 8.2% combined with local add-ons. The income tax savings are real, but the full picture is more complicated than "Texas has no income tax so it\'s cheaper."',
          'If you\'re renting or own a modest home, Texas is hard to beat on taxes. But a $600K house changes the math — that property tax bill can eat into your income tax savings fast. Run the numbers. That\'s literally what this calculator is for.',
        ],
        keyRates: [
          { label: 'Texas State Income Tax', value: '0%' },
          { label: 'TX Avg Property Tax Rate', value: '~1.71%' },
          { label: 'TX Avg Combined Sales Tax', value: '8.2%' },
          { label: 'Federal Standard Deduction', value: '$15,000 (single)' },
          { label: 'Social Security Rate', value: '6.2% (up to $176,100)' },
        ],
        faqs: TEXAS_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator (0% tax)' },
          { slug: 'illinois-tax-calculator', label: 'Illinois Calculator' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'new-york-tax-calculator', label: 'New York Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'florida':
      return {
        howItWorks: [
          'Florida: zero state income tax, just like Texas. But the property tax picture is completely different, and that\'s where Florida pulls ahead for a lot of people.',
          'Your paycheck deductions in Florida are federal tax only (2026 progressive brackets with standard deductions) plus FICA at 7.65% combined. No state tax, no local wage tax, nothing extra. Someone making $100K in Florida takes home thousands more per year than the same salary in Illinois, California, or New York.',
          'Here\'s where Florida really wins though:\n- Average effective <a href="https://floridarevenue.com/" target="_blank" rel="noopener noreferrer nofollow">property tax rate</a> of just 0.86% (Texas is ~1.71%)\n- Homestead Exemption knocks up to $50,000 off your home\'s assessed value\n- On a $300,000 home: roughly $2,580 property tax in Florida vs $5,130 in Texas',
          'I think Florida wins for retirees. And it\'s not even close. Social Security benefits, 401(k) distributions, IRA withdrawals, pensions — all completely tax-free at the state level. Add in the Homestead Exemption keeping property taxes low, and your fixed income stretches a lot further than in most states.',
          'Florida funds government through a 6% state sales tax (averaging 7% with local surtaxes) and tourism taxes. Visitors pay a big chunk of the bill, which is a nice perk for residents. No estate tax, no inheritance tax either.',
          'Bottom line — if you\'re comparing zero-tax states, <a href="/texas-tax-calculator">Florida tends to beat Texas</a> for homeowners and retirees. Run both calculators and see the difference.',
        ],
        keyRates: [
          { label: 'Florida State Income Tax', value: '0%' },
          { label: 'FL Avg Property Tax Rate', value: '~0.86%' },
          { label: 'FL Avg Combined Sales Tax', value: '7.0%' },
          { label: 'Homestead Exemption', value: 'Up to $50,000' },
          { label: 'Federal Standard Deduction', value: '$15,000 (single)' },
        ],
        faqs: FLORIDA_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'texas-tax-calculator', label: 'Texas Calculator (0% tax)' },
          { slug: 'illinois-tax-calculator', label: 'Illinois Calculator' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'new-york-tax-calculator', label: 'New York Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'california':
      return {
        howItWorks: [
          'California has the highest state income tax in the country. Top rate is 13.3%, and it starts at $698,271 of taxable income for single filers. Even at a modest salary you\'re probably paying 6%–9.3% to the state. I won\'t pretend that doesn\'t sting.',
          'The state uses <a href="https://www.ftb.ca.gov/" target="_blank" rel="noopener noreferrer nofollow">nine progressive brackets</a>. Standard deduction for 2026 is $6,083 (single) or $12,166 (married). After that deduction, each slice of your income gets its own rate — 1% on the first $10,099, climbing all the way to 13.3% above $698,271. Same principle as federal brackets: only the income within each bracket gets that rate. On top of this, you\'re paying federal progressive brackets with the $15,000 standard deduction, plus FICA at 7.65%. Pre-tax deductions like <a href="/401k-retirement-calculator">401(k) contributions</a> are huge in California because they cut your taxable income at both federal and state level. At 13.3% for high earners, that state deduction is worth a lot.',
          'One thing that catches people off guard: California property taxes are actually pretty reasonable. Average effective rate around 0.71%. Proposition 13 caps annual assessed value increases at 2%, so your tax bill doesn\'t spiral even if your home\'s market value goes crazy. Of course, when the median house costs $800K, even a low rate gives you a hefty bill. And at least Social Security benefits aren\'t taxed by the state.',
          'A coworker of mine was offered a $130K job in San Francisco and almost took it without running the numbers. California state tax alone on that salary is roughly $8,500. The same job in <a href="/texas-tax-calculator">Texas</a>? $0 state tax. That\'s not chump change. <a href="/relocation-calculator">Do the math before you accept that offer</a>.',
        ],
        keyRates: [
          { label: 'CA Tax Brackets', value: '1% – 13.3% (9 brackets)' },
          { label: 'CA Standard Deduction (Single)', value: '$6,083' },
          { label: 'CA Top Marginal Rate Threshold', value: '$698,271 (single)' },
          { label: 'CA Avg Combined Sales Tax', value: '8.82%' },
          { label: 'CA Avg Property Tax Rate', value: '~0.71%' },
        ],
        faqs: CALIFORNIA_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'texas-tax-calculator', label: 'Texas Calculator (0% tax)' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator (0% tax)' },
          { slug: 'illinois-tax-calculator', label: 'Illinois Calculator' },
          { slug: 'new-york-tax-calculator', label: 'New York Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'capital-gains-calculator', label: 'Capital Gains Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'newyork':
      return {
        howItWorks: [
          'New York takes a lot out of your paycheck. <a href="https://www.tax.ny.gov/" target="_blank" rel="noopener noreferrer nofollow">State income tax</a> runs from 4% to 10.9% across nine brackets, and if you live in NYC, there\'s an additional city tax (3.078%–3.876%) on top. NYC residents face the highest combined state and local income tax in the US.',
          'NY\'s standard deduction is $8,100 for single filers, $16,200 for married filing jointly — actually higher than California\'s, which is something. The top 10.9% rate doesn\'t kick in until $25,000,000 of taxable income, so most earners are in the 6%–8% range.',
          'That NYC tax though. If you live in any of the five boroughs, the city takes an additional 3.078%–3.876%. On $100,000, that\'s roughly $3,400 that people in literally any other US city don\'t pay. I\'ve seen friends reconsider job offers after factoring in the city tax. It\'s a toggle in this calculator for a reason — it makes a huge difference.',
          'One bright spot: New York doesn\'t tax Social Security, and excludes up to $20,000 of retirement income (pensions, 401(k), IRA) for taxpayers 59½ and older. Property taxes average 1.62% and combined sales tax is about 8.52%. Not great. But also not the worst part about living here.',
          'Winner for lowest total tax burden? Not New York, obviously. But if you\'re here for the career or the city, at least you can <a href="/compare">see exactly what it costs you compared to other states</a>.',
        ],
        keyRates: [
          { label: 'NY Tax Brackets', value: '4% – 10.9% (9 brackets)' },
          { label: 'NY Standard Deduction (Single)', value: '$8,100' },
          { label: 'NYC Income Tax', value: '3.078% – 3.876%' },
          { label: 'NY Avg Property Tax Rate', value: '~1.62%' },
          { label: 'NY Avg Combined Sales Tax', value: '8.52%' },
        ],
        faqs: NEWYORK_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'texas-tax-calculator', label: 'Texas Calculator (0% tax)' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator (0% tax)' },
          { slug: 'illinois-tax-calculator', label: 'Illinois Calculator' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'capital-gains-calculator', label: 'Capital Gains Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'mortgage':
      return {
        howItWorks: [
          'Your monthly mortgage payment comes from a formula: M = P × [r(1+r)^n] / [(1+r)^n - 1]. P is the loan amount, r is the monthly rate (annual rate ÷ 12), and n is total payments (years × 12). It spits out a fixed payment that pays off every penny by the end of the term. Simple enough. What surprises people is how that payment breaks down. On a 30-year, $280,000 loan at 6.5%, your first payment is roughly 86% interest and only 14% principal. You feel like you\'re treading water. By year 15 it\'s about 50/50, and in the final years nearly everything goes to principal. My brother bought his first house in 2019 and called me panicked after seeing his first amortization statement — "I\'m basically just paying interest!" Yeah. That\'s how it works at first. Stick with it.',
          'Extra payments go 100% toward principal. Every dollar you add saves you interest for the remaining life of the loan. Adding $200/month extra on that $280K loan at 6.5% saves roughly $76,856 in interest and pays it off more than 5 years early. Compound interest working for you instead of against you, for once.',
          'We generate a full amortization schedule — month by month, principal vs interest, remaining balance. For a detailed walkthrough, check the <a href="https://www.consumerfinance.gov/owning-a-home/" target="_blank" rel="noopener noreferrer nofollow">CFPB homebuying resources</a>. Key things to keep in mind:\n- Recommended housing cost ratio: no more than 28% of gross income\n- 20% down payment avoids PMI entirely\n- Common loan terms are 15, 20, or 30 years\n- Even small extra payments make a big difference over 30 years',
        ],
        keyRates: [
          { label: 'Formula', value: 'M = P × [r(1+r)^n] / [(1+r)^n - 1]' },
          { label: 'Common Loan Terms', value: '15, 20, or 30 years' },
          { label: 'Current Avg 30-Year Rate', value: '~6.5% (varies)' },
          { label: 'Recommended Housing Ratio', value: '≤28% of gross income' },
          { label: 'Typical Down Payment', value: '20% (avoids PMI)' },
        ],
        faqs: MORTGAGE_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: '401k-retirement-calculator', label: '401(k) Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'capital-gains-calculator', label: 'Capital Gains Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'retirement':
      return {
        howItWorks: [
          'Start early. That\'s the whole game with retirement savings. This calculator estimates your 401(k) balance at retirement based on contributions, employer match, expected returns, and years left to save. The earlier you begin, the less you need to put in each year.',
          'The math is future value of a series. Each year\'s contribution grows at your assumed annual return for every remaining year until retirement. Year 1 grows for the full period. Year 10 grows for 10 fewer years. Add it all up — that\'s your projected balance. The concept is straightforward. The results can be surprising. Someone who starts at 25 and contributes $500/month with a 7% return ends up with roughly $1.2 million by 65. Start at 35 with the same contributions? About $567,000. Ten years of delay costs you over $600K. That\'s compound growth for you — brutal if you\'re late, powerful if you\'re early.',
          'The employer match is free money. Typical structure: 50% match up to 6% of salary. Make $100K, contribute 6% ($6,000), employer adds $3,000. If you\'re not contributing enough to get the full match, you\'re throwing away thousands every year.',
          'For 2026, the <a href="https://www.irs.gov/retirement-plans/plan-participant-employee/retirement-topics-401k-and-profit-sharing-plan-contribution-limits" target="_blank" rel="noopener noreferrer nofollow">401(k) contribution limit is $23,500</a>. Catch-up contribution for ages 50+ is another $7,500. Ages 60-63 get an even bigger catch-up of $11,250. The calculator defaults to 7% annual return, which is a reasonable long-term assumption for a diversified stock portfolio. Real returns bounce around — up 20% some years, down 15% others — but 7% is a solid planning number over decades.',
          'RMD age is 73. That\'s when the IRS makes you start withdrawing. But that\'s a problem for future you.',
        ],
        keyRates: [
          { label: '2026 Contribution Limit', value: '$23,500' },
          { label: 'Catch-Up (Age 50+)', value: '+$7,500' },
          { label: 'Catch-Up (Age 60-63)', value: '+$11,250' },
          { label: 'Assumed Annual Return', value: '7% (default)' },
          { label: 'RMD Age', value: '73' },
        ],
        faqs: RETIREMENT_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'capital-gains-calculator', label: 'Capital Gains Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: 'mortgage-calculator', label: 'Mortgage Calculator' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator (retirees)' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'relocation':
      return {
        howItWorks: [
          'My sister got a job offer in San Francisco that paid $15,000 more than her Chicago salary. Sounded great until she ran the numbers. After California state tax and higher housing costs, she\'d actually have less money left over. That\'s exactly what this calculator prevents. It tells you the salary you\'d need in a new state to match your current take-home pay.',
          'How it works: first we calculate your current take-home after federal tax, FICA, and your state\'s income tax. Then we figure out what gross salary in the target state would give you the same net pay, accounting for that state\'s tax rates and deductions.',
          'Let\'s look at a real example. $100,000 in Texas (0% state tax) gets you roughly $79,000 take-home. To end up with the same $79,000 in California, you\'d need to earn about $120,000–$125,000. California\'s progressive income tax eats an extra $5,000–$8,000 that Texas doesn\'t touch. That\'s a car payment, a vacation, or a decent chunk of retirement savings — just gone to state tax.',
          'This tool focuses on income tax differences. But look, income tax isn\'t the whole story:\n- Property taxes: <a href="/texas-tax-calculator">Texas</a> is brutal (~1.71%), <a href="/california-tax-calculator">California</a> is surprisingly mild (~0.71%)\n- Sales taxes vary significantly by state and city\n- Housing costs are the big one — $1,500/month in Houston can be $3,000 in San Francisco\nCheck our <a href="/compare">state comparison pages</a> for the full picture.',
        ],
        keyRates: [
          { label: 'States Covered', value: 'IL, TX, FL, CA, NY' },
          { label: 'IL Flat Rate', value: '4.95%' },
          { label: 'TX / FL Rate', value: '0%' },
          { label: 'CA Top Rate', value: '13.3%' },
          { label: 'NY Top Rate (+ NYC)', value: '10.9% + 3.876%' },
        ],
        faqs: RELOCATION_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'illinois-tax-calculator', label: 'Illinois Calculator' },
          { slug: 'texas-tax-calculator', label: 'Texas Calculator' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'new-york-tax-calculator', label: 'New York Calculator' },
          { slug: 'mortgage-calculator', label: 'Mortgage Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'capital-gains':
      return {
        howItWorks: [
          'How long you hold an investment changes everything about the tax bill. Short-term gains (held a year or less) get taxed as ordinary income — up to 37%. Long-term gains (held more than a year) qualify for <a href="https://www.irs.gov/taxtopics/tc409" target="_blank" rel="noopener noreferrer nofollow">0%, 15%, or 20%</a>. On a $50,000 gain, the difference between short-term and long-term rates can be thousands of dollars.',
          'For 2026, the 0% long-term rate applies if your total taxable income (including the gain) is under $47,025 (single) or $94,050 (married). The 15% rate covers most people, up to $518,900 (single) or $583,750 (married). Above that, it\'s 20%. These brackets are based on your total taxable income, not just the gain — so your salary can push you into a higher capital gains bracket.',
          'Don\'t forget the Net Investment Income Tax (NIIT). That\'s an extra 3.8% on top when your MAGI exceeds $200,000 (single) or $250,000 (married).',
          'A guy I know sold some stock after 11 months because he wanted the cash for a down payment. Held it just 3 more weeks and he would\'ve qualified for long-term rates. Cost him about $4,000 in extra tax. That one still stings.',
          'The effective top rate on long-term gains is 23.8% (20% + 3.8% NIIT), not the 20% most people quote. We factor in your ordinary income to figure out which bracket your gains fall into, and we show you the NIIT impact too.',
          'Common tax-saving strategies worth knowing:\n- Tax-loss harvesting: offset gains with losses to reduce your tax bill\n- Watch your holding period: sometimes waiting a few weeks saves you thousands\n- Donate appreciated assets to charity: you deduct the full value and never pay capital gains on it\nSmall decisions, big savings.',
        ],
        keyRates: [
          { label: 'Short-Term Rate', value: 'Ordinary income (up to 37%)' },
          { label: 'Long-Term Rates', value: '0% / 15% / 20%' },
          { label: 'NIIT Rate', value: '3.8% (above $200K/$250K)' },
          { label: '0% Bracket (Single)', value: 'Up to $47,025 taxable' },
          { label: 'Top Effective Rate (incl. NIIT)', value: '23.8%' },
        ],
        faqs: CAPITAL_GAINS_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: '401k-retirement-calculator', label: '401(k) Calculator' },
          { slug: 'mortgage-calculator', label: 'Mortgage Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'self-employment':
      return {
        howItWorks: [
          '15.3%. That\'s the <a href="https://www.irs.gov/taxtopics/tc554" target="_blank" rel="noopener noreferrer nofollow">self-employment tax rate</a>, and if you just went freelance, it\'s probably higher than you expected. It covers both halves of Social Security (12.4%) and Medicare (2.9%) — the half your employer used to pay plus the half that always came out of your paycheck. Nobody warned me about this when I started consulting. It\'s a punch in the wallet.',
          'Here\'s a small relief: you don\'t pay 15.3% on 100% of your income. It\'s calculated on 92.35% of your net business income, which roughly accounts for the employer-half deduction that W-2 workers get automatically. So on $100,000 of net SE income, the tax base is $92,350 and the SE tax comes to roughly $14,130. Still hurts, but less than you might have feared at first glance. And you can deduct half of your SE tax ($7,065 in this example) as an above-the-line deduction. It doesn\'t reduce the SE tax itself, but it lowers your AGI, which means less federal and state income tax. Every bit counts.',
          'Quick reference for what you\'re dealing with:\n- Social Security portion: 12.4% on income up to $176,100\n- Medicare portion: 2.9% on everything, no cap\n- Additional Medicare: 0.9% on income above $200,000\n- Half of SE tax is deductible above the line',
          'Quarterly estimated payments. This is where new freelancers get into trouble. You have to send the IRS money four times a year — April 15, June 15, September 15, January 15 — or face penalties. The safe harbor is paying at least 100% of last year\'s tax liability (110% if your AGI was over $150,000) or 90% of this year\'s. We estimate those quarterly amounts so there are no ugly surprises in April. Seriously, don\'t skip estimated payments. The penalties aren\'t worth it.\n\nWant to see how self-employment income compares to a W-2 salary? <a href="/salary">Check our salary after tax pages</a> to compare take-home pay at every income level across all 5 states.',
        ],
        keyRates: [
          { label: 'SE Tax Rate', value: '15.3% on 92.35% of net income' },
          { label: 'Social Security Portion', value: '12.4% (up to $176,100)' },
          { label: 'Medicare Portion', value: '2.9% (no cap)' },
          { label: 'Additional Medicare', value: '0.9% (above $200K)' },
          { label: 'Half SE Tax Deduction', value: 'Above-the-line' },
        ],
        faqs: SELF_EMPLOYMENT_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'capital-gains-calculator', label: 'Capital Gains Calculator' },
          { slug: '401k-retirement-calculator', label: '401(k) Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'tax-refund':
      return {
        howItWorks: [
          'Your tax refund is simply the difference between what was withheld from your paychecks throughout the year and what you actually owe in taxes. If your employer withheld more than your total tax bill, the government sends you a refund. If they withheld less, you write a check. This <a href="/tax-refund-calculator">tax refund calculator</a> helps you figure out which scenario you\'re looking at before you file.',
          'The calculation goes like this: start with your total income, subtract deductions (standard or itemized) to get taxable income, apply the federal tax brackets, subtract any credits you qualify for, and that\'s your federal tax owed. Compare it to what was already withheld. The difference is your refund — or your balance due.',
          'The standard deduction for 2026 is $15,000 (single), $30,000 (married filing jointly), or $22,500 (head of household). Most people take the standard — about 90% of taxpayers. But if you have significant mortgage interest, charitable donations, or state/local taxes (SALT, capped at $10,000), itemizing might save you more. This calculator lets you try both.',
          'Tax credits are better than deductions — they reduce your tax bill dollar for dollar, while deductions only reduce your taxable income. The <a href="https://www.irs.gov/credits-deductions/individuals/child-tax-credit" target="_blank" rel="noopener noreferrer nofollow">Child Tax Credit</a> gives you $2,000 per qualifying child (up to $1,700 refundable). The Earned Income Credit can be worth up to $7,430 for families with three or more children. These credits can turn a small refund into a big one.',
          'A quick note on refund timing: if you e-file and choose direct deposit, most refunds arrive within 21 days. Paper returns take 6–8 weeks. The IRS typically starts accepting returns in late January, and filing early usually means faster processing. Just make sure you have all your documents (W-2, 1099, etc.) before you file.',
        ],
        keyRates: [
          { label: 'Standard Deduction (Single)', value: '$15,000' },
          { label: 'Standard Deduction (Married)', value: '$30,000' },
          { label: 'Child Tax Credit', value: '$2,000/child' },
          { label: 'Refundable Portion', value: 'Up to $1,700' },
          { label: 'EIC Max (3+ children)', value: '$7,430' },
        ],
        faqs: TAX_REFUND_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: '401k-retirement-calculator', label: '401(k) Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: 'capital-gains-calculator', label: 'Capital Gains Calculator' },
        ],
      };
    case 'sales-tax':
      return {
        howItWorks: [
          'Sales tax is the tax you pay on purchases — it\'s added at the register and calculated by multiplying the purchase price by the combined tax rate for your area. The combined rate includes both the state base rate and any local taxes (county, city, special district). On a $1,000 purchase in California at 8.82% combined rate, you pay $88.20 in sales tax for a total of $1,088.20.',
          'Four states charge 0% state sales tax: <a href="https://www.taxadmin.org/" target="_blank" rel="noopener noreferrer nofollow">Delaware, Montana, New Hampshire, and Oregon</a>. Alaska has no state sales tax but allows local taxes, resulting in a low average combined rate of about 1.82%. On the other end, Louisiana and Tennessee tie for the highest average combined rate at 9.56%.',
          'Local taxes make a real difference. The state base rate might be 6%, but your county and city can add another 2-3% on top. That\'s why the same purchase can cost different amounts depending on exactly where you are within a state. Our calculator uses average combined rates for each state to give you the most realistic estimate.',
          'Need to figure out the original price before tax from a receipt? That\'s the reverse sales tax calculation. Divide the total by (1 + tax rate). A $108.82 total in California = $108.82 ÷ 1.0882 = $100.00 original price. This comes in handy for expense reports and accounting.',
          'Since the 2018 <a href="https://www.supremecourt.gov/" target="_blank" rel="noopener noreferrer nofollow">Supreme Court decision in South Dakota v. Wayfair</a>, states can require online retailers to collect sales tax even without a physical presence. So most online purchases now include sales tax based on your location. Some states also have sales tax holidays — temporary periods where certain items (like back-to-school supplies) are exempt from sales tax.',
        ],
        keyRates: [
          { label: 'Average US Combined Rate', value: '~6.6%' },
          { label: 'Highest Combined Rate', value: '9.56% (LA/TN)' },
          { label: 'No Sales Tax States', value: 'DE, MT, NH, OR' },
          { label: 'CA Combined Rate', value: '8.82%' },
          { label: 'TX Combined Rate', value: '8.20%' },
        ],
        faqs: SALES_TAX_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'texas-tax-calculator', label: 'Texas Calculator' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'overtime':
      return {
        howItWorks: [
          'Overtime pay is calculated at 1.5x your regular hourly rate for hours worked beyond 40 in a week — that\'s the federal standard under the <a href="https://www.dol.gov/agencies/whd/overtime" target="_blank" rel="noopener noreferrer nofollow">Fair Labor Standards Act</a>. So if you make $30/hour, your OT rate is $45/hour. Sounds great until you see the taxes. Overtime is taxed as ordinary income at your marginal federal rate, plus FICA (7.65%), plus state income tax. For someone in the 22% federal bracket in a state like Illinois, the combined hit on OT earnings can approach 35%. That $45/hour OT becomes more like $29/hour after taxes.',
          'Here\'s the thing most people miss: overtime gets taxed at your marginal rate, not your effective rate. Your effective rate is the blended average across all brackets. But OT income stacks on top of your regular income, so it fills the highest bracket first. If your regular salary puts you at the top of the 12% bracket, every OT dollar is taxed at 22% federally. That\'s a big jump. Still, even at a higher tax rate, overtime puts more money in your pocket — just not as much as the gross number suggests.',
          'Some states have proposed eliminating state income tax on overtime pay, but as of 2026, no state has enacted such a law. Federal tax on overtime remains unchanged. Your best strategy is knowing your marginal rate before you volunteer for extra shifts so you can make an informed decision about whether the after-tax pay is worth the extra hours.',
          'A quick example: earning $20/hour with 10 hours of OT per week means an extra $300/week in gross OT pay. In a 22% federal bracket with 7.65% FICA and no state tax, you\'d keep about $211 of that $300. In Illinois with 4.95% state tax, you\'d keep about $196. Over a year of consistent OT, that\'s $10,000–$11,000 extra take-home — real money, but significantly less than the $15,600 gross.',
        ],
        keyRates: [
          { label: 'OT Pay Rate', value: '1.5x regular rate' },
          { label: 'Federal Tax on OT', value: 'At marginal rate (10%–37%)' },
          { label: 'FICA Rate', value: '7.65%' },
          { label: 'Typical Combined Tax on OT', value: '25%–35%' },
          { label: 'FLSA OT Threshold', value: 'After 40 hours/week' },
        ],
        faqs: OVERTIME_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'bonus-tax-calculator', label: 'Bonus Tax Calculator' },
          { slug: 'irs-withholding-calculator', label: 'IRS Withholding Calculator' },
          { slug: 'self-employment-tax-calculator', label: 'Self-Employment Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'georgia':
      return {
        howItWorks: [
          'Georgia charges a flat 5.49% income tax rate for 2026. That\'s it — one rate for everybody, whether you\'re making $40K or $400K. The state moved to a flat tax system recently, and the rate has been gradually decreasing. Georgia offers a standard deduction of $5,400 for single filers and $7,100 for married filing jointly, which comes off the top before the 5.49% applies. On a $75,000 salary (single), you\'re taxed on $69,600 after the deduction, which comes to about $3,821 in state tax.',
          'On top of Georgia state tax, you\'ve got the federal progressive brackets with the $15,000 standard deduction, plus FICA at 7.65% combined. So for a single person earning $75,000, the total tax picture looks like this: roughly $8,580 federal, $5,738 FICA, and $3,821 Georgia state tax. That leaves you with about $56,861 take-home — an effective total tax rate of about 24.2%.',
          'Georgia does offer some tax benefits worth noting. Social Security income is not taxed at the state level, and retirees aged 62+ can exclude up to $35,000 of retirement income ($70,000 for couples). That makes Georgia surprisingly competitive for retirees compared to states with higher flat rates like Illinois at 4.95% (though Illinois has a broader retirement income exemption). Property taxes in Georgia average about 0.87% — quite reasonable compared to the national average of 1.1%.',
          'If you\'re considering a move to Georgia, the flat tax is predictable and easier to plan around than progressive brackets. Compare it to <a href="/california-tax-calculator">California\'s 13.3% top rate</a> or <a href="/new-york-tax-calculator">New York\'s 10.9%</a> and the savings are significant for high earners. <a href="/relocation-calculator">Run the relocation calculator</a> to see the difference for your salary.',
        ],
        keyRates: [
          { label: 'Georgia Flat Tax Rate', value: '5.49%' },
          { label: 'GA Standard Deduction (Single)', value: '$5,400' },
          { label: 'GA Standard Deduction (Married)', value: '$7,100' },
          { label: 'GA Avg Property Tax Rate', value: '~0.87%' },
          { label: 'Retirement Income Exclusion (62+)', value: 'Up to $35,000' },
        ],
        faqs: GEORGIA_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'illinois-tax-calculator', label: 'Illinois Calculator (4.95%)' },
          { slug: 'virginia-tax-calculator', label: 'Virginia Calculator' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'lottery':
      return {
        howItWorks: [
          'Won the lottery? Congratulations — now let\'s talk about the tax bill. The IRS treats lottery winnings as ordinary income, and the withholding is 24% federal for winnings over $5,000. But here\'s the catch: 24% is just the withholding, not your actual tax rate. If your total income (winnings + salary + other income) puts you in the 32% or 37% bracket, you\'ll owe the difference when you file your return. On a $1 million prize, the 24% withholding is $240,000, but if your total tax rate is 37%, you owe another $130,000 at tax time.',
          'State taxes on lottery winnings vary widely. Some states — like California, Florida, Pennsylvania, and Texas — don\'t tax lottery winnings at all at the state level. Others, like New York, hit you with up to 10.9% state tax plus 3.876% NYC tax if you\'re a city resident. On a $1 million win in NYC, you could lose nearly 50% to combined federal, state, and city taxes. That\'s why where you live matters enormously when you win.',
          'Lump sum vs. annuity is the big decision. Most lotteries advertise the annuity total (e.g., "$100 million"), but the lump sum is typically about 50-60% of that. A $100 million annuity might have a $50 million lump sum. After 24% federal withholding on $50 million, that\'s $38 million. After the full 37% federal rate, it\'s $31.5 million. After state tax, it could be $27 million or less. The annuity spreads the tax hit over 30 years, which can keep you in lower brackets — but you\'re locked into the payment schedule.',
          'Don\'t forget that some states also have local taxes on top. And if you\'re thinking about moving to a no-tax state before claiming your prize — most states tax based on where the ticket was purchased, not where you live when you claim it. Always consult a tax professional before claiming a major prize.',
        ],
        keyRates: [
          { label: 'Federal Withholding', value: '24% (on winnings over $5K)' },
          { label: 'Top Federal Marginal Rate', value: '37%' },
          { label: 'States with No Lottery Tax', value: 'CA, FL, PA, TX, and more' },
          { label: 'Lump Sum vs Annuity', value: 'Lump sum ~50-60% of annuity total' },
          { label: 'NYC Combined Tax on Winnings', value: 'Up to ~50% total' },
        ],
        faqs: LOTTERY_TAX_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'capital-gains-calculator', label: 'Capital Gains Calculator' },
          { slug: 'tax-refund-calculator', label: 'Tax Refund Calculator' },
          { slug: 'irs-withholding-calculator', label: 'IRS Withholding Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'irs-withholding':
      return {
        howItWorks: [
          'Your W-4 form tells your employer how much federal tax to withhold from each paycheck. Too much withholding means a big refund but less money in each paycheck. Too little means bigger paychecks but a tax bill — and possibly penalties — in April. This calculator helps you find the sweet spot based on <a href="https://www.irs.gov/publications/p15t" target="_blank" rel="noopener noreferrer nofollow">IRS Publication 15-T</a>.',
          'The current W-4 (redesigned in 2020) no longer uses allowances. Instead, you enter your expected deductions, other income, and tax credits directly. The form has five steps: personal info, multiple jobs/spouse working, dependents, other adjustments, and signature. Most people only need Step 1 and Step 5. Steps 2-4 are for situations that make your withholding less straightforward.',
          'The safe harbor rule is your friend. To avoid underpayment penalties, you need to have withheld at least 90% of this year\'s tax liability OR 100% of last year\'s tax liability (110% if your AGI was over $150,000). If you owed less than $1,000 in tax for the year, you\'re also safe. The calculator shows you whether you\'re on track to meet the safe harbor, which is far more useful than just aiming for a refund.',
          'Common W-4 mistakes: not updating after getting married, having a second job, or having investment income. Each of these can throw off your withholding significantly. If you and your spouse both work and both check "Married" on your W-4 without accounting for the other\'s income, you\'ll almost certainly underpay. The fix is either Step 2 on the W-4 or using this calculator to figure out the right additional withholding amount.',
        ],
        keyRates: [
          { label: 'Standard Deduction (Single)', value: '$15,000' },
          { label: 'Standard Deduction (Married)', value: '$30,000' },
          { label: 'Safe Harbor (Prior Year)', value: '100% of last year\'s tax' },
          { label: 'Safe Harbor (High Income)', value: '110% if AGI > $150K' },
          { label: 'De Minimis Threshold', value: 'Owe less than $1,000 = no penalty' },
        ],
        faqs: IRS_WITHHOLDING_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'tax-refund-calculator', label: 'Tax Refund Calculator' },
          { slug: 'overtime-tax-calculator', label: 'Overtime Tax Calculator' },
          { slug: 'bonus-tax-calculator', label: 'Bonus Tax Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'property-tax':
      return {
        howItWorks: [
          'Property tax is calculated by multiplying your home\'s assessed value by the local effective tax rate. Simple formula, complicated reality. Your assessed value might not match your market value — some states assess at 100% of market value, others use a fraction. Illinois, for example, assesses residential property at about 10% of market value in Cook County. The rate itself varies enormously: New Jersey averages 2.49%, while Hawaii sits at 0.29%. On a $400,000 home, that\'s the difference between $9,960/year and $1,160/year. Same house value, wildly different tax bill.',
          'The national average effective property tax rate is about 1.1%. On a $300,000 home, that\'s roughly $3,300 per year or $275/month — often rolled into your mortgage payment via escrow. The states with the highest rates tend to be in the Northeast (New Jersey, Illinois, New Hampshire), while the lowest are in the South and West (Hawaii, Alabama, Colorado). But low property tax states often compensate with higher sales or income taxes, so the total tax burden tells a different story.',
          'Homestead exemptions can reduce your bill significantly. Florida knocks up to $50,000 off your assessed value if the property is your primary residence. Texas offers a $100,000 homestead exemption (increased in 2023). Some states also offer property tax freezes for seniors, disabled residents, or veterans. These exemptions aren\'t automatic — you have to apply for them, and many homeowners leave money on the table by not filing.',
          'Property taxes fund local services: schools, police, fire departments, road maintenance, and more. When you compare property taxes between areas, you\'re also comparing the quality and funding level of those services. A low rate in a rural county might mean underfunded schools. A high rate in a wealthy suburb might mean excellent public schools. The value you get matters as much as the amount you pay.',
          'This calculator uses average effective property tax rates for each state. Your actual rate depends on your specific county, city, school district, and any special assessment districts. Check your county tax assessor\'s website for the most precise rate for your address.',
        ],
        keyRates: [
          { label: 'US Average Effective Rate', value: '~1.1%' },
          { label: 'Highest Rate (NJ)', value: '~2.49%' },
          { label: 'Lowest Rate (HI)', value: '~0.29%' },
          { label: 'TX Avg Rate', value: '~1.71%' },
          { label: 'FL Avg Rate', value: '~0.86%' },
        ],
        faqs: PROPERTY_TAX_FAQS,
        relatedCalculators: [
          { slug: 'mortgage-calculator', label: 'Mortgage Calculator' },
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'texas-tax-calculator', label: 'Texas Calculator' },
          { slug: 'florida-tax-calculator', label: 'Florida Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'bonus-tax':
      return {
        howItWorks: [
          'Your year-end bonus is considered supplemental wages by the IRS, and there are two ways your employer can tax it. The flat rate method withholds 22% federally for bonuses under $1 million. That\'s simple and predictable — a $5,000 bonus gets $1,100 withheld for federal tax. The aggregate method combines your bonus with your regular paycheck and calculates withholding as if it\'s all regular income, which can push you into a higher withholding bracket temporarily.',
          'Here\'s where it gets interesting: the 22% flat rate is just the withholding, not your actual tax. If your total income puts you in the 24% or 32% bracket, you\'ll owe the difference when you file. On a $10,000 bonus, 22% withholding is $2,200. If your actual rate is 32%, you owe $3,200 — that\'s an extra $1,000 come tax time. On the other hand, if you\'re in the 12% bracket, you\'ll get a refund of the difference. The withholding is a prepayment, not the final bill.',
          'For bonuses over $1 million, the mandatory federal withholding rate jumps to 37%. Yes, 37% off the top for anything above that first million. Plus FICA at 7.65% on the full amount, plus state taxes. A $2 million bonus in California could see total withholding above 50%. That\'s why compensation packages for executives often include tax gross-ups — the company pays the tax on the tax.',
          'State taxes on bonuses follow the same rules as regular income. In a zero-income-tax state like Texas or Florida, you only pay federal withholding and FICA on your bonus. In California, add up to 13.3% state tax. The difference between receiving a $10,000 bonus in Texas vs California is roughly $1,000 in state tax alone. <a href="/relocation-calculator">Location matters</a>.',
        ],
        keyRates: [
          { label: 'Federal Flat Withholding', value: '22% (under $1M)' },
          { label: 'Federal Rate (over $1M)', value: '37%' },
          { label: 'FICA Rate', value: '7.65%' },
          { label: 'Aggregate Method', value: 'Combined with regular wages' },
          { label: 'Actual Tax vs Withholding', value: 'Reconcile at tax time' },
        ],
        faqs: BONUS_TAX_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'overtime-tax-calculator', label: 'Overtime Tax Calculator' },
          { slug: 'irs-withholding-calculator', label: 'IRS Withholding Calculator' },
          { slug: 'tax-refund-calculator', label: 'Tax Refund Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    case 'virginia':
      return {
        howItWorks: [
          'Virginia uses a progressive income tax with four brackets ranging from 2% to 5.75%. The 2% rate applies to your first $3,000 of taxable income (single) or $6,000 (married), then 3% up to $5,000/$10,000, 5% up to $17,000/$34,000, and 5.75% on everything above that. For most working professionals, the majority of your income falls into the 5.75% bracket. Virginia\'s standard deduction is $8,000 for single filers and $16,000 for married filing jointly — actually quite generous compared to states like California ($6,083) or Illinois (which has no standard deduction, just a $2,775 personal exemption).',
          'Let\'s run a real example. A single person earning $80,000 in Virginia: after the $8,000 standard deduction, taxable income is $72,000. Virginia tax comes to roughly $3,762.50. Add federal tax of about $9,660 and FICA of $6,120, and total taxes are about $19,542 — leaving you with roughly $60,458 take-home. That\'s an effective total tax rate of about 24.4%. Not bad compared to <a href="/california-tax-calculator">California</a> or <a href="/new-york-tax-calculator">New York</a>.',
          'Virginia has some decent tax benefits. Social Security benefits are fully exempt from state tax. Military pay is also exempt for Virginia National Guard members (up to $3,000) and active duty pay is exempt for those serving in a combat zone. The state also offers a deduction for long-term capital gains from certain qualifying investments. Property taxes average about 0.82%, which is below the national average of 1.1%.',
          'One thing to watch: Virginia doesn\'t allow local income taxes, unlike some states where cities or counties add their own tax on top. What you see at the state level is what you pay. That\'s different from <a href="/new-york-tax-calculator">New York City\'s 3.876% city tax</a> or the local taxes in some Pennsylvania and Ohio municipalities.',
        ],
        keyRates: [
          { label: 'VA Tax Brackets', value: '2% – 5.75% (4 brackets)' },
          { label: 'VA Standard Deduction (Single)', value: '$8,000' },
          { label: 'VA Standard Deduction (Married)', value: '$16,000' },
          { label: 'VA Avg Property Tax Rate', value: '~0.82%' },
          { label: 'Social Security Tax', value: 'Exempt' },
        ],
        faqs: VIRGINIA_FAQS,
        relatedCalculators: [
          { slug: 'paycheck-calculator', label: 'Paycheck Calculator' },
          { slug: 'georgia-tax-calculator', label: 'Georgia Calculator (5.49%)' },
          { slug: 'illinois-tax-calculator', label: 'Illinois Calculator (4.95%)' },
          { slug: 'california-tax-calculator', label: 'California Calculator' },
          { slug: 'relocation-calculator', label: 'Relocation Calculator' },
          { slug: 'salary', label: 'Salary After Tax' },
        ],
      };
    default:
      return {
        howItWorks: [
          'This calculator figures out your take-home pay after federal tax, FICA, and state income tax. Enter your gross salary, pick your state and filing status, and add any pre-tax deductions like 401(k) or HSA contributions if you have them.',
          'The results break down exactly where your money goes — every deduction, your effective tax rate, and your marginal rate. Pretty straightforward.',
        ],
        keyRates: [],
        faqs: HOME_FAQS,
        relatedCalculators: [],
      };
  }
}

// ─── Related Blog Posts by Calculator Type ────────────────────────────────────

const CALCULATOR_BLOG_SLUGS: Record<string, string[]> = {
  home: ['2026-federal-tax-brackets-explained', 'how-fica-taxes-work-2026'],
  illinois: ['illinois-income-tax-guide-2026', '2026-federal-tax-brackets-explained'],
  texas: ['why-texas-has-no-income-tax', 'florida-vs-texas-tax-comparison'],
  florida: ['florida-vs-texas-tax-comparison', 'why-texas-has-no-income-tax'],
  california: ['florida-vs-texas-tax-comparison', 'how-fica-taxes-work-2026'],
  newyork: ['how-fica-taxes-work-2026', '2026-federal-tax-brackets-explained'],
  mortgage: ['2026-federal-tax-brackets-explained'],
  retirement: ['how-fica-taxes-work-2026', '2026-federal-tax-brackets-explained'],
  relocation: ['florida-vs-texas-tax-comparison', 'why-texas-has-no-income-tax'],
  'capital-gains': ['how-fica-taxes-work-2026', '2026-federal-tax-brackets-explained'],
  'self-employment': ['how-fica-taxes-work-2026'],
  'sales-tax': ['sales-tax-by-state-guide-2026', 'florida-vs-texas-tax-comparison'],
  overtime: ['2026-federal-tax-brackets-explained', 'how-fica-taxes-work-2026'],
  georgia: ['2026-federal-tax-brackets-explained', 'florida-vs-texas-tax-comparison'],
  lottery: ['2026-federal-tax-brackets-explained', 'how-fica-taxes-work-2026'],
  'irs-withholding': ['2026-federal-tax-brackets-explained', 'how-fica-taxes-work-2026'],
  'property-tax': ['florida-vs-texas-tax-comparison', '2026-federal-tax-brackets-explained'],
  'bonus-tax': ['2026-federal-tax-brackets-explained', 'how-fica-taxes-work-2026'],
  virginia: ['2026-federal-tax-brackets-explained', 'florida-vs-texas-tax-comparison'],
};

// ─── Helper: Other States for Comparison ──────────────────────────────────────

function getOtherStates(currentState: string) {
  const states = [
    { slug: 'illinois-tax-calculator', name: 'Illinois', rate: '4.95%', key: 'illinois' },
    { slug: 'texas-tax-calculator', name: 'Texas', rate: '0%', key: 'texas' },
    { slug: 'florida-tax-calculator', name: 'Florida', rate: '0%', key: 'florida' },
    { slug: 'california-tax-calculator', name: 'California', rate: '1%–13.3%', key: 'california' },
    { slug: 'new-york-tax-calculator', name: 'New York', rate: '4%–10.9%', key: 'newyork' },
  ];
  return states.filter(s => s.key !== currentState);
}

// ─── Helper: FAQ Heading per Calculator Type ───────────────────────────────────

function getFaqHeading(type: string): string {
  switch (type) {
    case 'home': return 'Paycheck Calculator FAQ';
    case 'illinois': return 'Illinois Tax Calculator FAQ';
    case 'texas': return 'Texas Tax Calculator FAQ';
    case 'florida': return 'Florida Tax Calculator FAQ';
    case 'california': return 'California Tax Calculator FAQ';
    case 'newyork': return 'New York Tax Calculator FAQ';
    case 'mortgage': return 'Mortgage Calculator FAQ';
    case 'retirement': return '401(k) Retirement Calculator FAQ';
    case 'relocation': return 'Relocation Calculator FAQ';
    case 'capital-gains': return 'Capital Gains Tax FAQ';
    case 'self-employment': return 'Self-Employment Tax FAQ';
    case 'tax-refund': return 'Tax Refund Calculator FAQ';
    case 'sales-tax': return 'Sales Tax Calculator FAQ';
    case 'overtime': return 'Overtime Tax Calculator FAQ';
    case 'georgia': return 'Georgia Tax Calculator FAQ';
    case 'lottery': return 'Lottery Tax Calculator FAQ';
    case 'irs-withholding': return 'IRS Withholding Calculator FAQ';
    case 'property-tax': return 'Property Tax Calculator FAQ';
    case 'bonus-tax': return 'Bonus Tax Calculator FAQ';
    case 'virginia': return 'Virginia Tax Calculator FAQ';
    case 'income-tax': return 'Income Tax Calculator FAQ';
    case 'tax-calc': return 'Tax Calculator FAQ';
    default: return 'Frequently Asked Questions';
  }
}

// ─── Helper: Next Steps CTA Links ─────────────────────────────────────────────

function getNextSteps(type: string): { href: string; icon: string; title: string; description: string }[] {
  switch (type) {
    case 'home':
    case 'illinois':
    case 'texas':
    case 'florida':
    case 'california':
    case 'newyork':
      return [
        { href: '/401k-retirement-calculator', icon: '\u{1F3E6}', title: '401(k) Planner', description: 'Reduce taxable income with pre-tax contributions' },
        { href: '/compare', icon: '\u{1F4CA}', title: 'Compare States', description: 'See how your take-home compares across states' },
        { href: '/self-employment-tax-calculator', icon: '\u{1F4BC}', title: 'Self-Employment Tax', description: 'Freelancer? Calculate your SE tax' },
        { href: '/salary', icon: '\u{1F4B0}', title: 'Salary After Tax', description: 'Take-home pay for every salary level' },
      ];
    case 'mortgage':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'See if you can afford the monthly payment' },
        { href: '/401k-retirement-calculator', icon: '\u{1F3E6}', title: '401(k) Planner', description: 'Balance mortgage vs retirement savings' },
        { href: '/relocation-calculator', icon: '\u{1F3E0}', title: 'Relocation Calculator', description: 'Compare housing costs across states' },
        { href: '/capital-gains-calculator', icon: '\u{1F4C8}', title: 'Capital Gains Tax', description: 'Tax on selling your previous home' },
      ];
    case 'retirement':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'See how 401(k) contributions affect take-home' },
        { href: '/capital-gains-calculator', icon: '\u{1F4C8}', title: 'Capital Gains Tax', description: 'Tax implications of investment gains' },
        { href: '/mortgage-calculator', icon: '\u{1F3E0}', title: 'Mortgage Calculator', description: 'Will your home be paid off by retirement?' },
        { href: '/federal-tax-brackets', icon: '\u{1F4CB}', title: 'Tax Brackets 2026', description: 'Understand your marginal rate in retirement' },
      ];
    case 'capital-gains':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Your ordinary income affects capital gains rates' },
        { href: '/401k-retirement-calculator', icon: '\u{1F3E6}', title: '401(k) Planner', description: 'Tax-deferred growth vs taxable gains' },
        { href: '/self-employment-tax-calculator', icon: '\u{1F4BC}', title: 'Self-Employment Tax', description: 'SE income + capital gains = higher rates?' },
        { href: '/glossary', icon: '\u{1F4D6}', title: 'Tax Glossary', description: 'Key terms: NIIT, cost basis, holding period' },
      ];
    case 'self-employment':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Compare W-2 vs 1099 take-home pay' },
        { href: '/401k-retirement-calculator', icon: '\u{1F3E6}', title: 'Solo 401(k) Planner', description: 'Reduce SE tax with retirement contributions' },
        { href: '/capital-gains-calculator', icon: '\u{1F4C8}', title: 'Capital Gains Tax', description: 'Investment income on top of SE income' },
        { href: '/blog', icon: '\u{1F4DD}', title: 'Tax Guides', description: 'Deductions, quarterly payments, and more' },
      ];
    case 'tax-refund':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'See how withholding affects your take-home' },
        { href: '/401k-retirement-calculator', icon: '\u{1F3E6}', title: '401(k) Planner', description: 'Reduce your tax bill with pre-tax contributions' },
        { href: '/self-employment-tax-calculator', icon: '\u{1F4BC}', title: 'Self-Employment Tax', description: 'Estimate SE tax and quarterly payments' },
        { href: '/capital-gains-calculator', icon: '\u{1F4C8}', title: 'Capital Gains Tax', description: 'Investment gains can affect your refund' },
      ];
    case 'sales-tax':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Income tax vs sales tax breakdown' },
        { href: '/compare', icon: '\u{1F4CA}', title: 'Compare States', description: 'Full tax comparison across states' },
        { href: '/relocation-calculator', icon: '\u{1F3E0}', title: 'Relocation Calculator', description: 'Sales tax factors into cost of living' },
        { href: '/glossary', icon: '\u{1F4D6}', title: 'Tax Glossary', description: 'Key sales tax terms explained' },
      ];
    case 'overtime':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Full take-home pay breakdown' },
        { href: '/bonus-tax-calculator', icon: '\u{1F4B0}', title: 'Bonus Tax Calculator', description: 'Another type of supplemental pay' },
        { href: '/irs-withholding-calculator', icon: '\u{1F4CB}', title: 'IRS Withholding', description: 'Adjust W-4 for OT income' },
        { href: '/salary', icon: '\u{1F4C8}', title: 'Salary After Tax', description: 'Take-home pay at every level' },
      ];
    case 'georgia':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Full take-home pay breakdown' },
        { href: '/virginia-tax-calculator', icon: '\u{1F3E0}', title: 'Virginia Calculator', description: 'Compare VA 2%–5.75% vs GA 5.49%' },
        { href: '/relocation-calculator', icon: '\u{1F4CA}', title: 'Relocation Calculator', description: 'Compare GA to other states' },
        { href: '/salary', icon: '\u{1F4B0}', title: 'Salary After Tax', description: 'Take-home pay at every level' },
      ];
    case 'lottery':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Your regular income tax rate matters' },
        { href: '/capital-gains-calculator', icon: '\u{1F4C8}', title: 'Capital Gains Tax', description: 'Tax on investment income' },
        { href: '/tax-refund-calculator', icon: '\u{1F4CB}', title: 'Tax Refund Calculator', description: 'Will you owe or get a refund?' },
        { href: '/irs-withholding-calculator', icon: '\u{1F3E6}', title: 'IRS Withholding', description: 'Adjust withholding after big win' },
      ];
    case 'irs-withholding':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'See how withholding affects take-home' },
        { href: '/tax-refund-calculator', icon: '\u{1F4CB}', title: 'Tax Refund Calculator', description: 'Will you owe or get a refund?' },
        { href: '/overtime-tax-calculator', icon: '\u{1F4BC}', title: 'Overtime Tax', description: 'OT can change your withholding needs' },
        { href: '/bonus-tax-calculator', icon: '\u{1F4B0}', title: 'Bonus Tax', description: 'Bonus withholding is different' },
      ];
    case 'property-tax':
      return [
        { href: '/mortgage-calculator', icon: '\u{1F3E0}', title: 'Mortgage Calculator', description: 'Property tax is part of your payment' },
        { href: '/texas-tax-calculator', icon: '\u{1F4B5}', title: 'Texas Calculator', description: 'High property tax, no income tax' },
        { href: '/florida-tax-calculator', icon: '\u{1F3E0}', title: 'Florida Calculator', description: 'Low property tax, homestead exemption' },
        { href: '/relocation-calculator', icon: '\u{1F4CA}', title: 'Relocation Calculator', description: 'Property tax varies by state' },
      ];
    case 'bonus-tax':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Full take-home pay breakdown' },
        { href: '/overtime-tax-calculator', icon: '\u{1F4BC}', title: 'Overtime Tax', description: 'Another supplemental income type' },
        { href: '/irs-withholding-calculator', icon: '\u{1F4CB}', title: 'IRS Withholding', description: 'Adjust W-4 for bonus income' },
        { href: '/tax-refund-calculator', icon: '\u{1F3E6}', title: 'Tax Refund Calculator', description: 'Will bonus affect your refund?' },
      ];
    case 'virginia':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Full take-home pay breakdown' },
        { href: '/georgia-tax-calculator', icon: '\u{1F3E0}', title: 'Georgia Calculator', description: 'Compare GA 5.49% vs VA 2%–5.75%' },
        { href: '/relocation-calculator', icon: '\u{1F4CA}', title: 'Relocation Calculator', description: 'Compare VA to other states' },
        { href: '/salary', icon: '\u{1F4B0}', title: 'Salary After Tax', description: 'Take-home pay at every level' },
      ];
    case 'relocation':
      return [
        { href: '/paycheck-calculator', icon: '\u{1F4B5}', title: 'Paycheck Calculator', description: 'Full breakdown for any state' },
        { href: '/compare', icon: '\u{1F4CA}', title: 'State Comparison', description: 'Side-by-side tax comparison' },
        { href: '/mortgage-calculator', icon: '\u{1F3E0}', title: 'Mortgage Calculator', description: 'Housing costs in your new state' },
        { href: '/salary', icon: '\u{1F4B0}', title: 'Salary After Tax', description: 'Take-home for every salary level' },
      ];
    default:
      return [
        { href: '/compare', icon: '\u{1F4CA}', title: 'Compare States', description: 'Side-by-side tax comparison' },
        { href: '/salary', icon: '\u{1F4B0}', title: 'Salary After Tax', description: 'Take-home pay by salary level' },
        { href: '/glossary', icon: '\u{1F4D6}', title: 'Tax Glossary', description: 'Key tax terms explained' },
        { href: '/blog', icon: '\u{1F4DD}', title: 'Tax Guides', description: 'Expert tips and guides' },
      ];
  }
}

// ─── Server Component Page ────────────────────────────────────────────────────

export default async function CalculatorPage({
  params,
}: {
  params: Promise<{ calculator: string }>;
}) {
  const { calculator } = await params;
  const config = SLUG_TO_CONFIG[calculator];

  if (!config) {
    notFound();
  }

  const jsonLd = getJsonLdForType(config.jsonLdType);
  const content = getCalculatorContent(config.jsonLdType);

  // Fetch related blog posts from KV database
  const blogSlugs = CALCULATOR_BLOG_SLUGS[config.jsonLdType] ?? [];
  let relatedPosts: { slug: string; title: string; excerpt: string | null }[] = [];
  try {
    const allPosts = await getAllPosts();
    relatedPosts = allPosts
      .filter((p) => blogSlugs.includes(p.slug))
      .map((p) => ({ slug: p.slug, title: p.title, excerpt: p.excerpt || null }));
  } catch {
    // KV not available — skip related posts
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* JSON-LD Structured Data — Server Rendered */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* Breadcrumb — Semantic HTML for SEO */}
      <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-1.5 text-sm text-muted-foreground">
        <Link href="/" className="hover:text-foreground transition-colors">Home</Link>
        <span className="text-muted-foreground/50">/</span>
        <span className="text-foreground font-medium">{config.breadcrumbLabel}</span>
      </nav>

      {/* Share Buttons — Social signals for SEO */}
      <div className="mb-4 flex justify-center">
        <ShareButtons
          url={`${SITE_URL}${config.canonicalPath}`}
          title={config.title}
          description={config.metaDesc}
        />
      </div>

      {/* H1 — Semantic for SEO */}
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          {config.h1}
        </h1>
        <p className="mt-2 text-muted-foreground max-w-2xl mx-auto">
          {config.description}
        </p>
        {/* E-E-A-T: Last reviewed date */}
        <p className="mt-2 text-xs text-muted-foreground/60">
          Last reviewed: January 2026 · Tax data verified against IRS Publication 15-T &amp; state revenue departments
        </p>
      </div>

      {/* Client-Side Calculator */}
      <CalculatorClientPage componentKey={config.componentKey} />

      {/* Next Steps */}
      <section className="mt-8 rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-6 sm:p-8">
        <h3 className="text-lg font-semibold text-foreground mb-3">
          More {config.h1} Tools &amp; Resources
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {getNextSteps(config.componentKey).map((step) => (
            <Link
              key={step.href}
              href={step.href}
              className="flex items-start gap-2 rounded-lg p-2 hover:bg-emerald-500/10 transition-colors"
            >
              <span>{step.icon}</span>
              <div>
                <span className="text-sm font-medium text-foreground">{step.title}</span>
                <p className="text-xs text-muted-foreground">{step.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* ─── Server-Rendered Content for SEO ───────────────────────────────── */}
      <div className="mt-12 space-y-10">
        {/* How This Calculator Works */}
        <section className="rounded-xl border border-border/30 bg-card/50 p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            How the {config.h1} Works
          </h2>
          <div className="space-y-4">
            {content.howItWorks.map((paragraph, i) => (
              <p key={i} className="text-muted-foreground leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph.replace(/\n/g, '<br/>') }} />
            ))}
          </div>
        </section>

        {/* Key Rates & Data */}
        {content.keyRates.length > 0 && (
          <section className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-6 sm:p-8">
            <h2 className="text-2xl font-bold text-foreground mb-4">
              {config.h1} — Key Rates & Data for 2026
            </h2>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {content.keyRates.map((rate) => (
                <div
                  key={rate.label}
                  className="rounded-lg border border-border/30 bg-card/60 p-4"
                >
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">
                    {rate.label}
                  </p>
                  <p className="text-base font-bold text-foreground">
                    {rate.value}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Frequently Asked Questions */}
        {content.faqs.length > 0 && (
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-6">
              {getFaqHeading(config.componentKey)}
            </h2>
            <div className="space-y-3">
              {content.faqs.map((faq, i) => (
                <details
                  key={i}
                  className="group rounded-xl border border-border/30 bg-card/50 overflow-hidden"
                >
                  <summary className="flex cursor-pointer items-center justify-between gap-3 p-5 text-left font-medium text-foreground hover:bg-muted/10 transition-colors">
                    <h3 className="text-sm sm:text-base">{faq.question}</h3>
                    <svg
                      className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-180"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                  </summary>
                  <div className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </div>
                </details>
              ))}
            </div>
          </section>
        )}

        {/* Related Articles */}
        {relatedPosts.length > 0 && (
          <section className="rounded-xl border border-border/30 bg-card/50 p-6 sm:p-8">
            <p className="text-lg font-semibold text-foreground mb-4">
              Related Articles
            </p>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {relatedPosts.map((post) => (
                <Link
                  key={post.slug}
                  href={`/blog/${post.slug}`}
                  className="group rounded-lg border border-border/30 bg-card/60 p-4 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all"
                >
                  <h3 className="text-sm font-semibold text-foreground group-hover:text-emerald-400 transition-colors mb-1">
                    {post.title}
                  </h3>
                  {post.excerpt && (
                    <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">
                      {post.excerpt}
                    </p>
                  )}
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Related Calculators */}
        {content.relatedCalculators.length > 0 && (
          <section className="rounded-xl border border-border/30 bg-card/50 p-6 sm:p-8">
            <p className="text-lg font-semibold text-foreground mb-4">
              Related Calculators
            </p>
            <div className="flex flex-wrap gap-3">
              {content.relatedCalculators.map((calc) => (
                <Link
                  key={calc.slug}
                  href={`/${calc.slug}`}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-4 py-2 text-sm font-medium text-emerald-400 hover:bg-emerald-500/10 hover:border-emerald-500/50 transition-all"
                >
                  <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                  {calc.label}
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Link to Us — Encourage backlinks for DA */}
        <div className="mt-8">
          <LinkToUs
            url={`${SITE_URL}${config.canonicalPath}`}
            title={config.title}
            slug={config.slug}
          />
        </div>

        {/* Compare with Other States */}
        {['illinois', 'texas', 'florida', 'california', 'newyork'].includes(config.componentKey) && (
          <section className="rounded-xl border border-border/30 bg-card/50 p-6 sm:p-8">
            <p className="text-lg font-semibold text-foreground mb-4">
              Compare with Other States
            </p>
            <div className="flex flex-wrap gap-2">
              {getOtherStates(config.componentKey).map((state) => (
                <Link
                  key={state.slug}
                  href={`/${state.slug}`}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-border/50 px-3 py-1.5 text-sm hover:bg-accent/50 transition-colors"
                >
                  {state.name}
                  <span className="text-xs text-muted-foreground">({state.rate})</span>
                </Link>
              ))}
              <Link
                href="/compare"
                className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-1.5 text-sm font-medium text-emerald-400 hover:bg-emerald-500/10 transition-colors"
              >
                All State Comparisons →
              </Link>
            </div>
          </section>
        )}

        {/* Next Steps — contextual CTAs linking to salary and other tools */}
        <section className="rounded-xl border border-emerald-500/20 bg-gradient-to-br from-emerald-600/5 to-teal-600/5 p-6 sm:p-8">
          <p className="text-lg font-semibold text-foreground mb-4">
            Next Steps
          </p>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Link href="/salary" className="group flex items-start gap-3 rounded-lg border border-border/50 p-4 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all">
              <span className="text-lg">💰</span>
              <div>
                <span className="text-sm font-medium text-foreground group-hover:text-emerald-400 transition-colors">Salary After Tax</span>
                <p className="text-xs text-muted-foreground mt-0.5">See take-home pay for $30K–$500K across all 5 states</p>
              </div>
            </Link>
            <Link href="/compare" className="group flex items-start gap-3 rounded-lg border border-border/50 p-4 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all">
              <span className="text-lg">📊</span>
              <div>
                <span className="text-sm font-medium text-foreground group-hover:text-emerald-400 transition-colors">Compare States</span>
                <p className="text-xs text-muted-foreground mt-0.5">Side-by-side tax comparison for any two states</p>
              </div>
            </Link>
            <Link href="/relocation-calculator" className="group flex items-start gap-3 rounded-lg border border-border/50 p-4 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all">
              <span className="text-lg">🏠</span>
              <div>
                <span className="text-sm font-medium text-foreground group-hover:text-emerald-400 transition-colors">Relocation Calculator</span>
                <p className="text-xs text-muted-foreground mt-0.5">Salary you&apos;d need if you move to another state</p>
              </div>
            </Link>
            <Link href="/401k-retirement-calculator" className="group flex items-start gap-3 rounded-lg border border-border/50 p-4 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all">
              <span className="text-lg">📈</span>
              <div>
                <span className="text-sm font-medium text-foreground group-hover:text-emerald-400 transition-colors">401(k) Calculator</span>
                <p className="text-xs text-muted-foreground mt-0.5">Project your retirement savings with compound growth</p>
              </div>
            </Link>
            <Link href="/glossary" className="group flex items-start gap-3 rounded-lg border border-border/50 p-4 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all">
              <span className="text-lg">📖</span>
              <div>
                <span className="text-sm font-medium text-foreground group-hover:text-emerald-400 transition-colors">Tax Glossary</span>
                <p className="text-xs text-muted-foreground mt-0.5">Key tax terms explained in plain English</p>
              </div>
            </Link>
            <Link href="/federal-tax-brackets" className="group flex items-start gap-3 rounded-lg border border-border/50 p-4 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all">
              <span className="text-lg">📋</span>
              <div>
                <span className="text-sm font-medium text-foreground group-hover:text-emerald-400 transition-colors">Tax Brackets 2026</span>
                <p className="text-xs text-muted-foreground mt-0.5">Full federal bracket breakdown with examples</p>
              </div>
            </Link>
          </div>
        </section>

        {/* Link & Embed — Earns backlinks for Domain Authority */}
        <section className="rounded-xl border border-border/30 bg-card/50 p-6 sm:p-8">
          <p className="text-lg font-semibold text-foreground mb-4">
            Link to This Calculator
          </p>
          <p className="text-sm text-muted-foreground mb-4">
            Want to reference this tool on your website or blog? Copy the HTML below — no attribution required, but appreciated.
          </p>
          <div className="space-y-3">
            <div className="rounded-lg bg-muted/30 p-3">
              <p className="text-xs font-mono text-muted-foreground break-all">
                {`<a href="${SITE_URL}${config.canonicalPath}" title="${config.h1}">${config.h1} — TheTaxCalc</a>`}
              </p>
            </div>
            <p className="text-sm text-muted-foreground">
              Want to <Link href="/widgets" className="text-emerald-400 hover:text-emerald-300 underline">embed this calculator on your site</Link>? We offer free embeddable widgets for all our tools.
            </p>
            <div className="flex flex-wrap gap-2">
              <Link
                href="/widgets"
                className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-1.5 text-sm font-medium text-emerald-400 hover:bg-emerald-500/10 transition-all"
              >
                📎 Free Embed Widgets
              </Link>
              <Link
                href="/resources"
                className="inline-flex items-center gap-1.5 rounded-lg border border-border/50 px-3 py-1.5 text-sm text-muted-foreground hover:text-emerald-400 hover:border-emerald-500/30 transition-all"
              >
                📊 Tax Data & Rates
              </Link>
            </div>
          </div>
        </section>

        {/* Explore More Tools */}
        <section className="rounded-xl border border-border/30 bg-card/50 p-6 sm:p-8">
          <p className="text-lg font-semibold text-foreground mb-4">
            Explore More Tools
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <Link href="/compare" className="flex items-center gap-2 rounded-lg border border-border/50 p-3 hover:bg-accent/50 transition-colors">
              <span className="text-sm font-medium">📊 Compare States</span>
              <span className="text-xs text-muted-foreground">Side-by-side tax comparison</span>
            </Link>
            <Link href="/salary" className="flex items-center gap-2 rounded-lg border border-border/50 p-3 hover:bg-accent/50 transition-colors">
              <span className="text-sm font-medium">💰 Salary After Tax</span>
              <span className="text-xs text-muted-foreground">Take-home for $30K–$500K</span>
            </Link>
            <Link href="/federal-tax-brackets" className="flex items-center gap-2 rounded-lg border border-border/50 p-3 hover:bg-accent/50 transition-colors">
              <span className="text-sm font-medium">📋 Tax Brackets 2026</span>
              <span className="text-xs text-muted-foreground">Federal brackets & rates</span>
            </Link>
            <Link href="/glossary" className="flex items-center gap-2 rounded-lg border border-border/50 p-3 hover:bg-accent/50 transition-colors">
              <span className="text-sm font-medium">📖 Tax Glossary</span>
              <span className="text-xs text-muted-foreground">Key terms explained</span>
            </Link>
            <Link href="/blog" className="flex items-center gap-2 rounded-lg border border-border/50 p-3 hover:bg-accent/50 transition-colors">
              <span className="text-sm font-medium">📝 Tax Guides & Blog</span>
              <span className="text-xs text-muted-foreground">Expert tax tips & guides</span>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
